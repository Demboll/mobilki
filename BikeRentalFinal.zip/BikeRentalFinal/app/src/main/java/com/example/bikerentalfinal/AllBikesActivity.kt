package com.example.bikerentalfinal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bikerentalfinal.data.AppDatabase
import com.example.bikerentalfinal.data.Bike
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AllBikesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    private lateinit var appDb: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_bikes)

        appDb = AppDatabase.getDatabase(this)

        viewManager = LinearLayoutManager(this)
        viewAdapter = BikeAdapter(emptyList())

        recyclerView = findViewById<RecyclerView>(R.id.recycler_view).apply {
            setHasFixedSize(true)
            layoutManager = viewManager
            adapter = viewAdapter
        }

        fetchBikes()
    }

    private fun fetchBikes() {
        lifecycleScope.launch {
            val bikes = withContext(Dispatchers.IO) {
                appDb.bikeDao().getAll()
            }
            viewAdapter = BikeAdapter(bikes)
            recyclerView.adapter = viewAdapter
        }
    }
}
