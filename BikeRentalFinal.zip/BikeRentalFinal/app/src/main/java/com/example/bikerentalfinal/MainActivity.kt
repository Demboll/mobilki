package com.example.bikerentalfinal

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.bikerentalfinal.databinding.ActivityMainBinding
import com.example.bikerentalfinal.data.AppDatabase
import com.example.bikerentalfinal.data.Bike
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appDb: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appDb = AppDatabase.getDatabase(this)

        binding.btnSaveBike.setOnClickListener {
            writeData()
        }

        binding.btnReadData.setOnClickListener {
            readData()
        }

        binding.btnDeleteAll.setOnClickListener {
            deleteAllData()
        }

        binding.btnViewAllBikes.setOnClickListener {
            val intent = Intent(this@MainActivity, AllBikesActivity::class.java)
            startActivity(intent)
        }
    }

    private fun writeData() {
        val bikeBrand = binding.etBikeBrand.text.toString()
        val bikeModel = binding.etBikeModel.text.toString()
        val bikeId = binding.etBikeId.text.toString().toIntOrNull()
        val bikeImageUrl = binding.etBikeImageUrl.text.toString()

        if (bikeBrand.isNotEmpty() && bikeModel.isNotEmpty() && bikeId != null && bikeImageUrl.isNotEmpty()) {
            val bike = Bike(null, bikeBrand, bikeModel, bikeId, bikeImageUrl)

            lifecycleScope.launch {
                appDb.bikeDao().insert(bike)
                Toast.makeText(this@MainActivity, "Bike saved", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun readData() {
        val bikeId = binding.etFindBike.text.toString().toIntOrNull()

        if (bikeId != null) {
            lifecycleScope.launch {
                val bike = appDb.bikeDao().findByBikeId(bikeId)
                if (bike != null) {
                    binding.tvBikeBrand.text = "Bike brand: ${bike.brand}"
                    binding.tvBikeModel.text = "Bike model: ${bike.model}"
                    binding.tvBikeId.text = "Bike ID: ${bike.bikeId}"
                } else {
                    Toast.makeText(this@MainActivity, "No bike found", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Please enter a bike ID", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteAllData() {
        lifecycleScope.launch {
            appDb.bikeDao().deleteAll()
            Toast.makeText(this@MainActivity, "All bikes deleted", Toast.LENGTH_SHORT).show()

            // Clear text views
            binding.tvBikeBrand.text = ""
            binding.tvBikeModel.text = ""
            binding.tvBikeId.text = ""
        }
    }
}