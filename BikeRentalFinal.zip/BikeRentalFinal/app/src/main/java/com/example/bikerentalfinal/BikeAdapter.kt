package com.example.bikerentalfinal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bikerentalfinal.data.Bike

class BikeAdapter(private val bikes: List<Bike>) : RecyclerView.Adapter<BikeAdapter.BikeViewHolder>() {

    class BikeViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val bikeBrand: TextView = view.findViewById(R.id.bike_brand)
        val bikeModel: TextView = view.findViewById(R.id.bike_model)
        val bikeId: TextView = view.findViewById(R.id.bike_id)
        val bikeImage: ImageView = view.findViewById(R.id.bike_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BikeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bike, parent, false) as View
        return BikeViewHolder(view)
    }

    override fun onBindViewHolder(holder: BikeViewHolder, position: Int) {
        val bike = bikes[position]
        holder.bikeBrand.text = bike.brand
        holder.bikeModel.text = bike.model
        holder.bikeId.text = bike.bikeId.toString()
        Glide.with(holder.view.context).load(bike.imageUrl).into(holder.bikeImage)
    }

    override fun getItemCount() = bikes.size
}
